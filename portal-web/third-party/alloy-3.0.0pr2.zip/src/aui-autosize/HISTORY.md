# AUI AutoSize

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-autosize).

## @VERSION@

No registries yet.

## [3.0.0pr1](https://github.com/liferay/alloy-ui/releases/tag/3.0.0pr1)

* [AUI-1174](https://issues.liferay.com/browse/AUI-1174) Validate source code with JSHint
* [AUI-1278](https://issues.liferay.com/browse/AUI-1278) A.Plugin.AutosizeIframe.getContentHeight returns wrong content heights
* [AUI-1273](https://issues.liferay.com/browse/AUI-1273) Describe source code changes in HISTORY.md

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants